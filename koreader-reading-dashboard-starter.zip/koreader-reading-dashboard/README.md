# My KOReader Plugins

Personal KOReader plugins designed for my Kindle.

## Plugins

### Reading Dashboard

Current version: `0.1.0`

Location:

```text
readingdashboard.koplugin/
```

Install/update:

```sh
/mnt/us/install-readingdashboard.sh YOUR_GITHUB_USERNAME/koreader-plugins
```

More plugins can be added alongside it as separate `.koplugin` directories.
